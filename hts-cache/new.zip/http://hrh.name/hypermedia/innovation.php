<!DOCTYPE html>
<html lang="en">
    <head>

    <title>Tim Italy</title>
    <meta charset='utf-8'>
    <meta name="description" content="Tim Italy Website design">
    <meta name="keywords" content="TIM,HYPERMEDIA">
    <meta name="author" content="Hamidreza Hanafi">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <script type="text/javascript" src="js/main.js"></script>
    </head>
    <body>
    	<div class="container">
    		<div class="header">
    			<div class="logo">
    				<img src="images/logo.png" height="61" width="185" />
    			</div>
    			<div class="tollfree">
    				Toll FREE 800(233)HELP
    			</div>
    			<div class="blue"></div>
    		</div>
	<div class="sidebar">
		<ul>
			<li><a href="index.php">Home Page</a></li>
			<li><a href="innovation.php" class="active">Who We Are</a>
			<ul>
				<li><a href="innovation.php" class="active">Innovation</a></li>
				<li><a href="testimonials.php">Testemonials</a></li>
				<li><a href="projects.php">Projects</a></li>
			</ul>
			</li>
			<li><a href="group.php">Group</a></li>
			<li><a href="devices.php">All Devices</a></li>
			<li><a href="sl.php">All SL Services</a></li>
			<li><a href="assist.php">All Assistant Services</a></li>
		</ul>
	</div>
	<div class="maincontent">
		<a href="">
			<div class="homepagepic" style="background-image: url('images/4.jpg');">
				<div class="homepagetitle"> Innovation </div>
			</div>
		</a>
		<div class="pagecontent">
			The new symbol of the company renews its identity and confirms TIM�s leading position in the telecommunications sector in this digital age, was today presented in Rome
Tim Berners-Lee, Fabio Fazio and Pif, are featured in testimonials that are part of the institutional advertising campaign for the launch of the new logo
The TIM Towers restructuring project, which in Rome will host the company�s central offices, was also presented		</div>
	</div>
	            <div class="footer">
                <div>
                    Telecom Italia 2012 - P.IVA 00488410010
                </div>
            </div>
        </div>
    </body>
</html>