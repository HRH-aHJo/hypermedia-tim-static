<!DOCTYPE html>
<html lang="en">
    <head>

    <title>Tim Italy</title>
    <meta charset='utf-8'>
    <meta name="description" content="Tim Italy Website design">
    <meta name="keywords" content="TIM,HYPERMEDIA">
    <meta name="author" content="Hamidreza Hanafi">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <script type="text/javascript" src="js/main.js"></script>
    </head>
    <body>
    	<div class="container">
    		<div class="header">
    			<div class="logo">
    				<img src="images/logo.png" height="61" width="185" />
    			</div>
    			<div class="tollfree">
    				Toll FREE 800(233)HELP
    			</div>
    			<div class="blue"></div>
    		</div>
	<div class="sidebar">
		<ul>
			<li><a href="index.php">Home Page</a></li>
			<li><a href="innovation.php" class="active">Who We Are</a></li>
			<li><a href="group.php">Group</a>
				<ul>
					<li><a href="group.php">Group Description</a></li>
					<li><a href="news.php" class="active">News</a></li>
					<li><a href="governance.php">Governance</a></li>
					<li><a href="business.php">Business & Market</a></li>
					<li><a href="investors.php">For Investors</a></li>
				</ul>
			</li>
			<li><a href="devices.php">All Devices</a></li>
			<li><a href="sl.php">All SL Services</a></li>
			<li><a href="assist.php">All Assistant Services</a></li>
		</ul>
	</div>
	<div class="maincontent">
		<a href="">
			<div class="homepagepic" style="background-image: url('images/8.png');">
				<div class="homepagetitle"> News </div>
			</div>
		</a>
		<div class="pagecontent">
			<p>
			<span style="font-family: Arial;">INWIT Press Release<br />
			<br />
			06/23/2016 - 07:25 PM<br />
			INWIT: financial calendar amended - Board of Directors&rsquo; meeting to approve the half-yearly report brought forward to 25th July<br />
			<br />
			TI CORPORATE Press Release<br />
			<br />
			06/20/2016 - 10:08 PM<br />
			Telecom Italia Group: Giorgio Valerio appointed Director of the Nomination and Remuneration Committee<br />
			<br />
			TI CORPORATE Press Release<br />
			<br />
			06/17/2016 - 07:54 AM<br />
			Telecom Italia: Financial Calendar Updated - BoD to approve 1H16 results anticipated to 26 July<br />
			<br />
			TI CORPORATE Press Release<br />
			<br />
			06/16/2016 - 02:35 PM<br />
			Special Shareholders&#39; meeting held: Dario Trevisan confirmed as Common Representative for Savings Share Shareholders</span></p>		</div>
	</div>
	            <div class="footer">
                <div>
                    Telecom Italia 2012 - P.IVA 00488410010
                </div>
            </div>
        </div>
    </body>
</html>