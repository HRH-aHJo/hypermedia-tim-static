<!DOCTYPE html>
<html lang="en">
    <head>

    <title>Tim Italy</title>
    <meta charset='utf-8'>
    <meta name="description" content="Tim Italy Website design">
    <meta name="keywords" content="TIM,HYPERMEDIA">
    <meta name="author" content="Hamidreza Hanafi">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <script type="text/javascript" src="js/main.js"></script>
    </head>
    <body>
    	<div class="container">
    		<div class="header">
    			<div class="logo">
    				<img src="images/logo.png" height="61" width="185" />
    			</div>
    			<div class="tollfree">
    				Toll FREE 800(233)HELP
    			</div>
    			<div class="blue"></div>
    		</div>
	<div class="sidebar">
		<ul>
			<li><a href="index.php">Home Page</a></li>
			<li><a href="innovation.php" class="active">Who We Are</a></li>
			<li><a href="group.php">Group</a></li>
			<li><a href="devices.php">All Devices</a>
				<ul>
					<li><a href="devices.php" class="active">All Devices & Devices by category</a></li>
					<li><a href="devices.php?promo=1"  >Promotions</a></li>
				</ul>
			</li>
			<li><a href="sl.php">All SL Services</a></li>
			<li><a href="assist.php">All Assistant Services</a></li>
		</ul>
	</div>
	<div class="maincontent">
		<div class="othertitle"> All Devices </div>
		<div>
			<a href="devices.php?category=1">
				<div class="category">
					<div>
						<img src="images/smart.png" /> 
					</div>
					<div class="cattext">
						Smartphones
					</div>
									</div>
			</a>
			<a href="devices.php?category=2">
				<div class="category">
					<div>
						<img src="images/tablet.png" /> 
					</div>
					<div class="cattext">
						Tablets
					</div>
									</div>
			</a>
			<a href="devices.php?category=3">
				<div class="category">
					<div>
						<img src="images/modem.png" /> 
					</div>
					<div class="cattext">
						Modems
					</div>
									</div>
			</a>
			<a href="devices.php?category=4">
				<div class="category">
					<div>
						<img src="images/tv.png" /> 
					</div>
					<div class="cattext">
						TV
					</div>
									</div>
			</a>
			<a href="devices.php?category=5">
				<div class="category">
					<div>
						<img src="images/outlet.png" /> 
					</div>
					<div class="cattext">
						Outlet
					</div>
									</div>
			</a>
		</div>
		<div class="pagecontent">
			<table>				<tr class="device">
					<td>
						<img src="images/lg-g5-titan.png" width="186" height="186" />
					</td>
					<td class="devicename">
						LG G5					</td>
					<td style="vertical-align:bottom;">
												<span class="price" style="">699.90 €</span>
						<button style="font" onclick="redirect('device.php?id=1')">Details</button>
					</td>
				</tr>
			
						</table>
		</div>
	</div>
	            <div class="footer">
                <div>
                    Telecom Italia 2012 - P.IVA 00488410010
                </div>
            </div>
        </div>
    </body>
</html>