<!DOCTYPE html>
<html lang="en">
    <head>

    <title>Tim Italy</title>
    <meta charset='utf-8'>
    <meta name="description" content="Tim Italy Website design">
    <meta name="keywords" content="TIM,HYPERMEDIA">
    <meta name="author" content="Hamidreza Hanafi">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <script type="text/javascript" src="js/main.js"></script>
    </head>
    <body>
    	<div class="container">
    		<div class="header">
    			<div class="logo">
    				<img src="images/logo.png" height="61" width="185" />
    			</div>
    			<div class="tollfree">
    				Toll FREE 800(233)HELP
    			</div>
    			<div class="blue"></div>
    		</div>
	<div class="sidebar">
		<ul>
			<li><a href="index.php">Home Page</a></li>
			<li><a href="innovation.php" class="active">Who We Are</a></li>
			<li><a href="group.php">Group</a></li>
			<li><a href="devices.php">All Devices</a></li>
			<li><a href="sl.php">All SL Services</a>
				<ul>
					<li><a href="sl.php" class="active">All SL Services & Services by category</a></li>
					<li><a href="sl.php?promo=1"  >Promotions</a></li>
				</ul>
			</li>
			<li><a href="assist.php">All Assistant Services</a></li>
		</ul>
	</div>
	<div class="maincontent">
		<div class="othertitle"> All Smart Life Services </div>
		<div>
			<a href="sl.php?category=1">
				<div class="category">
					<div>
						<img src="images/sltv.png" /> 
					</div>
					<div class="cattext">
						TV & Entertainment
					</div>
									</div>
			</a>
			<a href="sl.php?category=2">
				<div class="category">
					<div>
						<img src="images/health.png" /> 
					</div>
					<div class="cattext">
						Health
					</div>
									</div>
			</a>
			<a href="sl.php?category=3">
				<div class="category">
					<div>
						<img src="images/slhome.png" /> 
					</div>
					<div class="cattext">
						Home & Family
					</div>
									</div>
			</a>
			<a href="sl.php?category=4">
				<div class="category">
					<div>
						<img src="images/personal.png" /> 
					</div>
					<div class="cattext">
						Personal
					</div>
									</div>
			</a>
		</div>
		<div class="pagecontent">
			<table>				<tr class="device">
					<td>
						<img src="images/logo_tim_music.jpg" width="186" height="186" />
					</td>
					<td class="devicename">
						<div style="font-weight:bold">
							TIM Music						</div>
						<div>
						Listen to millions of songs streaming, all new releases,
exclusive previews and many playlist of all kinds. On smartphones
without consuming GB, PC and tablet. When you want and how much you want.						</div>
					</td>
					<td style="vertical-align:bottom;">
						<div class="promo">PROMO</div>						<button onclick="redirect('onesl.php?id=1')">Details</button>
					</td>
				</tr>
			
						</table>
		</div>
	</div>
	            <div class="footer">
                <div>
                    Telecom Italia 2012 - P.IVA 00488410010
                </div>
            </div>
        </div>
    </body>
</html>