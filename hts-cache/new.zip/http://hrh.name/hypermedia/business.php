<!DOCTYPE html>
<html lang="en">
    <head>

    <title>Tim Italy</title>
    <meta charset='utf-8'>
    <meta name="description" content="Tim Italy Website design">
    <meta name="keywords" content="TIM,HYPERMEDIA">
    <meta name="author" content="Hamidreza Hanafi">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <script type="text/javascript" src="js/main.js"></script>
    </head>
    <body>
    	<div class="container">
    		<div class="header">
    			<div class="logo">
    				<img src="images/logo.png" height="61" width="185" />
    			</div>
    			<div class="tollfree">
    				Toll FREE 800(233)HELP
    			</div>
    			<div class="blue"></div>
    		</div>
	<div class="sidebar">
		<ul>
			<li><a href="index.php">Home Page</a></li>
			<li><a href="innovation.php" class="active">Who We Are</a></li>
			<li><a href="group.php">Group</a>
				<ul>
					<li><a href="group.php">Group Description</a></li>
					<li><a href="news.php">News</a></li>
					<li><a href="governance.php">Governance</a></li>
					<li><a href="business.php" class="active">Business & Market</a></li>
					<li><a href="investors.php">For Investors</a></li>
				</ul>
			</li>
			<li><a href="devices.php">All Devices</a></li>
			<li><a href="sl.php">All SL Services</a></li>
			<li><a href="assist.php">All Assistant Services</a></li>
		</ul>
	</div>
	<div class="maincontent">
		<a href="">
			<div class="homepagepic" style="background-image: url('images/9.jpg');">
				<div class="homepagetitle"> Business & Market </div>
			</div>
		</a>
		<div class="pagecontent">
			<p style="margin: 0.8125em 0px; font-size: 0.8125em; line-height: 1.25; text-align: justify; color: rgb(34, 34, 34); box-sizing: inherit !important; background-color: rgb(255, 255, 255);">
			<font size="3"><span style="font-family: Arial;">Our strategic markets are Italy and Brasil. Operations are conducted by dedicate Business Units:&nbsp; the<strong style="box-sizing: inherit !important;">Domestic Business Unit&nbsp;</strong>-&nbsp; it includes fixed and mobile voce and data services for retail customers and wholesale operators, as well as&nbsp; international wholesale services (Telecom Italia Sparkle ) and IT solutions (Olivetti) -&nbsp; and the<strong style="box-sizing: inherit !important;">&nbsp;Brazil Busines Unit</strong>&nbsp;(TIM Brasil). &nbsp; &nbsp; &nbsp;</span></font></p>
		<p style="margin: 0.8125em 0px; font-size: 0.8125em; line-height: 1.25; text-align: justify; color: rgb(34, 34, 34); box-sizing: inherit !important; background-color: rgb(255, 255, 255);">
			<font size="3"><span style="font-family: Arial;">Our organisation, in line with the evolution of the sector business models and market and technological trends, is shifting towards a&nbsp;<strong style="box-sizing: inherit !important;">&ldquo;Digital Telco &amp; Platform Company&rdquo;</strong>&nbsp;model based on innovative infrastructure and an excellent&nbsp; customer service,increasingly aimed at disseminating premium services and digital content within a customisable platform, accessible anywhere and on any device.</span></font></p>
		<p style="margin: 0.8125em 0px; font-size: 0.8125em; line-height: 1.25; text-align: justify; color: rgb(34, 34, 34); box-sizing: inherit !important; background-color: rgb(255, 255, 255);">
			<font size="3"><span style="font-family: Arial;">Commercial management of the retail customers - namely private (individual consumers and families) and business customers - is based on these organizational drivers:</span></font></p>
		<ul style="margin: 0.8125em 0px; padding: 0px 0px 0px 2.5em; font-size: 0.8125em; line-height: 1.25; text-align: justify; overflow: hidden; color: rgb(34, 34, 34); box-sizing: inherit !important; background-color: rgb(255, 255, 255);">
			<li style="box-sizing: inherit !important; list-style: none; margin-left: -1em; padding-left: 1em; background-image: url(&quot;/etc/designs/ti-rwd/cmn/v4/img/layout/article-list-dot-red.png&quot;); background-position: left 0.4375em; background-repeat: no-repeat;">
				<font size="3"><span style="font-family: Arial;">guaranteeing the end-to-end accountability of the marketing, sales and post-sales processes for each customer segment,</span></font></li>
			<li style="box-sizing: inherit !important; list-style: none; margin-left: -1em; padding-left: 1em; background-image: url(&quot;/etc/designs/ti-rwd/cmn/v4/img/layout/article-list-dot-red.png&quot;); background-position: left 0.4375em; background-repeat: no-repeat;">
				<font size="3"><span style="font-family: Arial;">encouraging the development of integrated &ldquo;customer centric&rdquo; offers and the focus on digital market services</span></font></li>
			<li style="box-sizing: inherit !important; list-style: none; margin-left: -1em; padding-left: 1em; background-image: url(&quot;/etc/designs/ti-rwd/cmn/v4/img/layout/article-list-dot-red.png&quot;); background-position: left 0.4375em; background-repeat: no-repeat;">
				<font size="3"><span style="font-family: Arial;">creating synergies between commercial channels to increase the efficiency and effectiveness of the multichannel model</span></font></li>
			<li style="box-sizing: inherit !important; list-style: none; margin-left: -1em; padding-left: 1em; background-image: url(&quot;/etc/designs/ti-rwd/cmn/v4/img/layout/article-list-dot-red.png&quot;); background-position: left 0.4375em; background-repeat: no-repeat;">
				<font size="3"><span style="font-family: Arial;">encouraging the development of &ldquo;platform based&rdquo; services expanding TIM&#39;s offer portfolio</span></font></li>
			<li style="box-sizing: inherit !important; list-style: none; margin-left: -1em; padding-left: 1em; background-image: url(&quot;/etc/designs/ti-rwd/cmn/v4/img/layout/article-list-dot-red.png&quot;); background-position: left 0.4375em; background-repeat: no-repeat;">
				<font size="3"><span style="font-family: Arial;">paying attention to multinational customers in order to develop international connectivity.</span></font></li>
		</ul>
		<p style="margin: 0.8125em 0px; font-size: 0.8125em; line-height: 1.25; text-align: justify; color: rgb(34, 34, 34); box-sizing: inherit !important; background-color: rgb(255, 255, 255);">
			<font size="3"><span style="font-family: Arial;">For this purpose activities on the domestic market are structured into these main departments.</span></font></p>
		<h5 style="font-size: 1em; margin: 1em 0px 0.8125em; line-height: 1.15em; color: rgb(34, 34, 34); box-sizing: inherit !important; background-color: rgb(255, 255, 255);">
			<font size="3"><span style="font-family: Arial;">Consumer &amp; Small Enterprise Market</span></font></h5>
		<p style="margin: 0.8125em 0px; font-size: 0.8125em; line-height: 1.25; text-align: justify; color: rgb(34, 34, 34); box-sizing: inherit !important; background-color: rgb(255, 255, 255);">
			<font size="3"><span style="font-family: Arial;">This department is responsible for ensuring the operating margin of the consumer and small business segments, protecting and increasing the value of the customers, maximizing revenues, profitability and market shares through the definition of the offer and marketing plans, commercial communication, the marketing of products/services, caring activities, operating credit and the administrative management of the customers, with the aim of increasing customer satisfaction and optimizing the overall costs of the service. From an organizational perspective, the company&nbsp;<strong style="box-sizing: inherit !important;">Persidera,</strong>&nbsp;created from a merger between Telecom Italia Media Broadcasting and Rete A, reports to this department.</span></font></p>
		</div>
	</div>
	            <div class="footer">
                <div>
                    Telecom Italia 2012 - P.IVA 00488410010
                </div>
            </div>
        </div>
    </body>
</html>