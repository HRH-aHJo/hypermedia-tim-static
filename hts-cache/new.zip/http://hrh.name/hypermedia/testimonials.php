<!DOCTYPE html>
<html lang="en">
    <head>

    <title>Tim Italy</title>
    <meta charset='utf-8'>
    <meta name="description" content="Tim Italy Website design">
    <meta name="keywords" content="TIM,HYPERMEDIA">
    <meta name="author" content="Hamidreza Hanafi">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <script type="text/javascript" src="js/main.js"></script>
    </head>
    <body>
    	<div class="container">
    		<div class="header">
    			<div class="logo">
    				<img src="images/logo.png" height="61" width="185" />
    			</div>
    			<div class="tollfree">
    				Toll FREE 800(233)HELP
    			</div>
    			<div class="blue"></div>
    		</div>
	<div class="sidebar">
		<ul>
			<li><a href="index.php">Home Page</a></li>
			<li><a href="innovation.php" class="active">Who We Are</a>
			<ul>
				<li><a href="innovation.php">Innovation</a></li>
				<li><a href="testimonials.php" class="active">Testemonials</a></li>
				<li><a href="projects.php">Projects</a></li>
			</ul>
			</li>
			<li><a href="group.php">Group</a></li>
			<li><a href="devices.php">All Devices</a></li>
			<li><a href="sl.php">All SL Services</a></li>
			<li><a href="assist.php">All Assistant Services</a></li>
		</ul>
	</div>
	<div class="maincontent">
		<a href="">
			<div class="homepagepic" style="background-image: url('images/5.jpg');">
				<div class="homepagetitle"> testimonials </div>
			</div>
		</a>
		<div class="pagecontent">
			<p>
			<span style="font-family:arial,helvetica,sans-serif;">&nbsp;<span style="color: rgb(51, 51, 51); font-size: 17px; line-height: 28px; text-indent: -5.1px; background-color: rgb(255, 255, 255);">&ldquo;We have been very impressed by David&rsquo;s ability to literally read our minds and deliver a corporate identity that perfectly symbolizes our vision and conveys the stylish, elegant and modern image we needed to sustain the international development of our company.&rdquo;</span></span></p>
		<br style="color: rgb(51, 51, 51); font-family: GalanoGrotesque-Regular, Helvetica, sans-serif; font-size: 17px; line-height: 28px; text-indent: -5.1px; background-color: rgb(255, 255, 255);" />
		<p>
			<span style="font-family:arial,helvetica,sans-serif;"><big><span class="source" style="border: 0px none; font-size: 16px; margin: 8px 0px 0px; outline: none 0px; padding: 0px 0px 0px 20px; vertical-align: baseline; display: block; text-transform: lowercase; text-indent: 0em; color: rgb(51, 51, 51); line-height: 28px; background-color: rgb(255, 255, 255);">&mdash; david sadigh, founder, dlg</span></big><br />
			<span style="color: rgb(51, 51, 51); font-size: 17px; line-height: 28px; text-indent: -5.1px; background-color: rgb(255, 255, 255);">&ldquo;We were looking for a logo with a touch of modernism. David grasped our needs and produced a stunning design. When feedback was needed, new versions of the logo or any modifications were made very quickly. We really appreciated David&rsquo;s flexibility and efficiency. It&rsquo;s great to work with someone so open-minded and responsive. Thank you!&rdquo;</span><br style="color: rgb(51, 51, 51); font-family: GalanoGrotesque-Regular, Helvetica, sans-serif; font-size: 17px; line-height: 28px; text-indent: -5.1px; background-color: rgb(255, 255, 255);" />
			<span class="source" style="border: 0px; font-size: 16px; margin: 8px 0px 0px; outline: 0px; padding: 0px 0px 0px 20px; vertical-align: baseline; display: block; text-transform: lowercase; text-indent: 0em; color: rgb(51, 51, 51); line-height: 28px; background-color: rgb(255, 255, 255);">&mdash; cyrille ehrhart, henri ehrhart</span><br />
			<br />
			<span style="color: rgb(51, 51, 51); font-size: 17px; line-height: 28px; text-indent: -5.1px; background-color: rgb(255, 255, 255);">&ldquo;Awesome to work with. Incredibly organized, easy to communicate with, responsive with next iterations, and beautiful work.&rdquo;</span></span></p>
		<p>
			<span class="source" style="border: 0px; font-family: GalanoGrotesque-Regular, Helvetica, sans-serif; font-size: 16px; margin: 8px 0px 0px; outline: 0px; padding: 0px 0px 0px 20px; vertical-align: baseline; display: block; text-transform: lowercase; text-indent: 0em; color: rgb(51, 51, 51); line-height: 28px; background-color: rgb(255, 255, 255);"><span style="font-family:arial,helvetica,sans-serif;">&mdash; stuart levinson, co-founder, talkto</span></span></p>		</div>
	</div>
	            <div class="footer">
                <div>
                    Telecom Italia 2012 - P.IVA 00488410010
                </div>
            </div>
        </div>
    </body>
</html>