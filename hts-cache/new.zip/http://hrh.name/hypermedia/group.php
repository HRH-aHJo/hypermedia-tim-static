<!DOCTYPE html>
<html lang="en">
    <head>

    <title>Tim Italy</title>
    <meta charset='utf-8'>
    <meta name="description" content="Tim Italy Website design">
    <meta name="keywords" content="TIM,HYPERMEDIA">
    <meta name="author" content="Hamidreza Hanafi">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <script type="text/javascript" src="js/main.js"></script>
    </head>
    <body>
    	<div class="container">
    		<div class="header">
    			<div class="logo">
    				<img src="images/logo.png" height="61" width="185" />
    			</div>
    			<div class="tollfree">
    				Toll FREE 800(233)HELP
    			</div>
    			<div class="blue"></div>
    		</div>
	<div class="sidebar">
		<ul>
			<li><a href="index.php">Home Page</a></li>
			<li><a href="innovation.php" class="active">Who We Are</a></li>
			<li><a href="group.php">Group</a>
				<ul>
					<li><a href="group.php" class="active">Group Description</a></li>
					<li><a href="news.php">News</a></li>
					<li><a href="governance.php">Governance</a></li>
					<li><a href="business.php">Business & Market</a></li>
					<li><a href="investors.php">For Investors</a></li>
				</ul>
			</li>
			<li><a href="devices.php">All Devices</a></li>
			<li><a href="sl.php">All SL Services</a></li>
			<li><a href="assist.php">All Assistant Services</a></li>
		</ul>
	</div>
	<div class="maincontent">
		<a href="">
			<div class="homepagepic" style="background-image: url('images/7.png');">
				<div class="homepagetitle"> Group Description </div>
			</div>
		</a>
		<div class="pagecontent">
			<h3 style="font-weight: 400; margin: 0px 0px 5px; font-size: 14px; padding-bottom: 5px; padding-top: 5px; font-family: arial, sans-serif !important;">
			<small><font size="3"><small><span style="font-family: Arial;">We develop new generation infrastructures with the goal of ensuring that around 84% of Italian houses have coverage via the new fixed ultra-broadband network and 98% of the population via&nbsp; the new mobile network by the end of 2018. As we believe digital technologies are the basis for a smart, sustainable and inclusive growth. By the end of March 2016, with a total of 11 million km of installed fiber, the fixed network has already reached 45% of the houses and 1,100 municipalities; the mobile network reached 92% of the population and 6,200 municipalities.<br />
			<br />
			To simplify the daily life there are new solutions: electronic payment systems, smart homes, electronic medical records and certified electronic mail in the healthcare and government sectors, for the schools&nbsp; interactive multimedia whiteboards and web-based learning environments. For businesses, advanced platforms for cloud computing for the virtualization of applications and infrastructures, a vast selection of applications for storing and managing data or controlling energy consumption, products and software to enhance the use of digital signatures.<br />
			<br />
			For everyone, digital technology means to be always connected and access services and digital&nbsp; content - games, e-books, music and films, all constantly enriched with premium contents - with ease and safety; all of this seamlessly on smartphones, tablets or other devices. &nbsp;<br />
			<br />
			Through the TIM Foundation we promote a vision of innovation and technology as social enablers, supporting projects in the fields of&nbsp; digital education and cultural innovation. As a result of the company&rsquo;s social and environmental commitment, we have been included among the most important and selective stock market Sustainability indexes worldwide, for the last eleven years.</span></small></font></small></h3>
		</div>
	</div>
	            <div class="footer">
                <div>
                    Telecom Italia 2012 - P.IVA 00488410010
                </div>
            </div>
        </div>
    </body>
</html>