<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en-US">
<head>
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Hamidreza Hanafi &raquo; Page not found</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">      
 



<link rel="alternate" type="application/rss+xml" title="Hamidreza Hanafi &raquo; Feed" href="http://hrh.name/feed/" />
<link rel="alternate" type="application/rss+xml" title="Hamidreza Hanafi &raquo; Comments Feed" href="http://hrh.name/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"http:\/\/s.w.org\/images\/core\/emoji\/72x72\/","ext":".png","source":{"concatemoji":"http:\/\/hrh.name\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.3.5"}};
			!function(a,b,c){function d(a){var c=b.createElement("canvas"),d=c.getContext&&c.getContext("2d");return d&&d.fillText?(d.textBaseline="top",d.font="600 32px Arial","flag"===a?(d.fillText(String.fromCharCode(55356,56812,55356,56807),0,0),c.toDataURL().length>3e3):(d.fillText(String.fromCharCode(55357,56835),0,0),0!==d.getImageData(16,16,1,1).data[0])):!1}function e(a){var c=b.createElement("script");c.src=a,c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g;c.supports={simple:d("simple"),flag:d("flag")},c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.simple&&c.supports.flag||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='wpeden-bootstrap-css'  href='http://hrh.name/wp-content/themes/sensitive/bootstrap/css/bootstrap.css?ver=4.3.5' type='text/css' media='all' />
<link rel='stylesheet' id='wpeden-bootstrap-responsive-css'  href='http://hrh.name/wp-content/themes/sensitive/bootstrap/css/bootstrap-responsive.css?ver=4.3.5' type='text/css' media='all' />
<link rel='stylesheet' id='wpeden-main-css'  href='http://hrh.name/wp-content/themes/sensitive/style.css?ver=4.3.5' type='text/css' media='all' />
<script type='text/javascript' src='http://hrh.name/wp-includes/js/jquery/jquery.js?ver=1.11.3'></script>
<script type='text/javascript' src='http://hrh.name/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.2.1'></script>
<script type='text/javascript' src='http://hrh.name/wp-content/themes/sensitive/bootstrap/js/bootstrap.min.js?ver=4.3.5'></script>
<script type='text/javascript' src='http://hrh.name/wp-content/themes/sensitive/js/site.js?ver=4.3.5'></script>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://hrh.name/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://hrh.name/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.3.5" />
    
    <style type="text/css">
    .footer,
    .navbar-wrapper{
            }
    .footer p,
    .footer,
    .widget-footer h3,
    .footer a,
    .wpeden-intro h2,
    .wpeden-intro p{
        
    }
    
    </style>
    
    	<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
<script type="text/javascript">
//<![CDATA[
	var screen_res = ""; 
	function writeCookie(name,value,hours) {
		var the_cookie = name+"="+escape(value)+"; expires=";
		var expires = "";
		hours=hours+0; //convert to number
		if (hours > 0) { //0==expires on browser close
			var cdate = new Date();
			cdate.setTime(cdate.getTime()+(hours*60*60*1000));
			expires = expires+cdate.toGMTString();
		} 
		document.cookie = the_cookie+expires+"; path=/; domain=";
	}
	screen_res = screen.width+" x "+screen.height;
	if (screen_res==" x ") screen_res = window.screen.width+" x "+window.screen.height;
	if (screen_res==" x ") screen_res = screen.availWidth+" x "+screen.availHeight;
	if (screen_res!=" x ") { 
		writeCookie("wassup_screen_res",screen_res,"48"); //keep 2 days
	} else {
		screen_res = "";
	}
//]]>
</script>
</head>
<body class="error404">
<div class="wide">
     
<!-- NAVBAR
    ================================================== -->
    <div class="navbar-wrapper">
      <!-- Wrap the .navbar in .container to center it within the absolutely positioned parent. -->
      <div class="container" id="topmenu">

        <div class="navbar">
          <div class="navbar-inner">
            <!-- Responsive Navbar Part 1: Button for triggering responsive navbar (not covered in tutorial). Include responsive CSS to utilize. -->
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </a>
            <a class="brand" href="http://hrh.name/">Hamidreza Hanafi</a>
            <!-- Responsive Navbar Part 2: Place all navbar contents you want collapsed withing .navbar-collapse.collapse. -->
            <div class="nav-collapse collapse">
              <ul id="menu-menu-1" class="nav"><li id="menu-item-175" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-175"><a href="http://hrh.name/resume/">Resume</a></li>
<li id="menu-item-170" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children dropdown menu-item-170"><a href="http://hrh.name/projects/" class="dropdown-toggle" data-toggle="dropdown">Projects <b class="caret"></b></a>
<ul class="dropdown-menu" role='menu' aria-labelledby="dLabel">
	<li id="menu-item-174" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-174"><a href="http://hrh.name/projects/jerry/">Jerry</a></li>
	<li id="menu-item-171" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-171"><a href="http://hrh.name/projects/bms/">BMS</a></li>
	<li id="menu-item-173" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-173"><a href="http://hrh.name/projects/das/">Data Acquisition System</a></li>
	<li id="menu-item-214" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-214"><a href="http://hrh.name/projects/rop/">Retinopathy of prematurity (ROP)</a></li>
	<li id="menu-item-172" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-172"><a href="http://hrh.name/projects/cms/">Content Management System</a></li>
</ul>
</li>
<li id="menu-item-167" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-167"><a href="http://hrh.name/blog/">Blog</a></li>
<li id="menu-item-168" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-168"><a href="http://hrh.name/contact-me/">Contact Me</a></li>
</ul>            </div><!--/.nav-collapse -->
	    <div style="float:right;padding-top:9px;width:96px" >
	    	<a style="float: left;" target="_blank" href="https://facebook.com/hamidreza.hanafi">
		<img class="gray aligncenter" src="http://hrh.name/wp-content/themes/sensitive/images/facebook-3-32.png" />
		</a>
		<a style="float: left;" target="_blank" href="https://twitter.com/HRH0001">
		<img class="gray aligncenter" src="http://hrh.name/wp-content/themes/sensitive/images/twitter-3-32.png" />
		</a>
		<a style="float: left;" target="_blank" href="https://plus.google.com/111447439988389976072">
		<img class="gray aligncenter" src="http://hrh.name/wp-content/themes/sensitive/images/google-plus-3-32.png" />
		</a>
	    </div>
          </div><!-- /.navbar-inner -->
        </div><!-- /.navbar -->

      </div> <!-- /.container -->
      
            
            
    </div><!-- /.navbar-wrapper -->
            
     
            
<div class="clear"></div>  
<div class="col2 green_posts single">
     
</div>
<div class="col1 sidebar">
 
<div class="box widget"><form role="search" method="get" id="searchform" class="searchform" action="http://hrh.name/">
				<div>
					<label class="screen-reader-text" for="s">Search for:</label>
					<input type="text" value="" name="s" id="s" />
					<input type="submit" id="searchsubmit" value="Search" />
				</div>
			</form></div>		<div class="box widget">		<h3>Recent Posts</h3>		<ul>
					<li>
				<a href="http://hrh.name/first-post/">First Post</a>
						</li>
				</ul>
		</div><div class="box widget"><h3>Recent Comments</h3><ul id="recentcomments"><li class="recentcomments"><span class="comment-author-link"><a href='http://hrh.name/first-post/' rel='external nofollow' class='url'>Hamidreza Hanafi &raquo; First Post</a></span> on <a href="http://hrh.name/resume/#comment-2">Resume</a></li></ul></div><div class="box widget"><h3>Archives</h3>		<ul>
	<li><a href='http://hrh.name/2013/10/'>October 2013</a></li>
		</ul>
</div><div class="box widget"><h3>Categories</h3>		<ul>
	<li class="cat-item cat-item-4"><a href="http://hrh.name/category/news/" >News</a>
</li>
		</ul>
</div><div class="box widget"><h3>Meta</h3>			<ul>
						<li><a href="http://hrh.name/wp-login.php">Log in</a></li>
			<li><a href="http://hrh.name/feed/">Entries <abbr title="Really Simple Syndication">RSS</abbr></a></li>
			<li><a href="http://hrh.name/comments/feed/">Comments <abbr title="Really Simple Syndication">RSS</abbr></a></li>
<li><a href="https://wordpress.org/" title="Powered by WordPress, state-of-the-art semantic personal publishing platform.">WordPress.org</a></li>			</ul>
</div></div>
        <!-- The JavaScript -->

        
 <div class="footer">
<div class="container">
<div class="row">
<div class="header">
<div class="span4">
</div>
<div class="span4">
</div>
<div class="span4">
</div>
<div class="clear"></div>
</div>
</div> 
</div>
<div class="content ftxt">Copyright &copy; Hamidreza Hanafi | Designed by <a href='http://wpeden.com'>WP Eden</a> | Powered by <a href='http://wordpress.org'>WordPress</a></div>
</div>
 




<!--[if IE]>
<script language=javascript>
//<![CDATA[
	if (screen_res=="") {
		screen_res = screen.width + " x " + screen.height;
	}
	if (screen_res!=" x ") {
		var cdate = new Date();
		cdate.setTime(cdate.getTime()+(48*60*60*1000));
		var cexpires = cdate.toGMTString();
		//var the_cookie = "wassup_screen_res="+escape(screen_res)+"; expires="+cexpires;
		document.cookie = "wassup_screen_res=" + escape(screen_res)+ "; path=/; domain=" + document.domain;

	}
//]]>
</script>
<![endif]--><!--
<p class="small"> WassUp 1.8.6 timestamp: 2016-07-01 12:08:32AM UTC (03:38AM)<br />
If above timestamp is not current time, this page is cached.</p> -->
<script type='text/javascript' src='http://hrh.name/wp-includes/js/comment-reply.min.js?ver=4.3.5'></script>
</div>
</body>
</html>