<!DOCTYPE html>
<html lang="en">
    <head>

    <title>Tim Italy</title>
    <meta charset='utf-8'>
    <meta name="description" content="Tim Italy Website design">
    <meta name="keywords" content="TIM,HYPERMEDIA">
    <meta name="author" content="Hamidreza Hanafi">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <script type="text/javascript" src="js/main.js"></script>
    </head>
    <body>
    	<div class="container">
    		<div class="header">
    			<div class="logo">
    				<img src="images/logo.png" height="61" width="185" />
    			</div>
    			<div class="tollfree">
    				Toll FREE 800(233)HELP
    			</div>
    			<div class="blue"></div>
    		</div>
	<div class="sidebar">
		<ul>
			<li><a href="index.php">Home Page</a></li>
			<li><a href="innovation.php" class="active">Who We Are</a></li>
			<li><a href="group.php">Group</a></li>
			<li><a href="devices.php">All Devices</a></li>
			<li><a href="sl.php">All SL Services</a></li>
			<li><a href="assist.php">All Assistant Services</a>
				<ul>
					<li><a href="assist.php" class="active">All Assistant Services & Services by category</a></li>
					<li><a href="assist.php?highlight=1"  >Highlights</a></li>
				</ul>
			</li>
		</ul>
	</div>
	<div class="maincontent">
		<div class="othertitle"> All Assistant Services </div>
		<div>
			<a href="assist.php?category=1">
				<div class="category">
					<div>
						<img src="images/sltv.png" /> 
					</div>
					<div class="cattext">
						Line Management
					</div>
									</div>
			</a>
			<a href="assist.php?category=2">
				<div class="category">
					<div>
						<img src="images/pay.png" /> 
					</div>
					<div class="cattext">
						Cost & Payment control
					</div>
									</div>
			</a>
			<a href="assist.php?category=3">
				<div class="category">
					<div>
						<img src="images/texh.png" /> 
					</div>
					<div class="cattext">
						Technical Support
					</div>
									</div>
			</a>
			<a href="assist.php?category=4">
				<div class="category">
					<div>
						<img src="images/sl.png" /> 
					</div>
					<div class="cattext">
						Smart Life
					</div>
									</div>
			</a>
		</div>
		<div class="pagecontent">
			<table>				<tr class="device">
					<td class="devicename" style="width:650px;">
						<div style="font-weight:bold">
							TIMgames							<span class="highlight">HIGHLIGHT</span>						</div>
					</td>
					<td style="vertical-align:bottom;">
						<button onclick="redirect('oneassist.php?id=1')">Details</button>
					</td>
				</tr>
			
						</table>
		</div>
	</div>
	            <div class="footer">
                <div>
                    Telecom Italia 2012 - P.IVA 00488410010
                </div>
            </div>
        </div>
    </body>
</html>