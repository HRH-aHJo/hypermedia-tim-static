<!DOCTYPE html>
<html lang="en">
    <head>

    <title>Tim Italy</title>
    <meta charset='utf-8'>
    <meta name="description" content="Tim Italy Website design">
    <meta name="keywords" content="TIM,HYPERMEDIA">
    <meta name="author" content="Hamidreza Hanafi">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <script type="text/javascript" src="js/main.js"></script>
    </head>
    <body>
    	<div class="container">
    		<div class="header">
    			<div class="logo">
    				<img src="images/logo.png" height="61" width="185" />
    			</div>
    			<div class="tollfree">
    				Toll FREE 800(233)HELP
    			</div>
    			<div class="blue"></div>
    		</div>
	<div class="sidebar">
		<ul>
			<li><a href="index.php">Home Page</a></li>
			<li><a href="innovation.php" class="active">Who We Are</a>
			<ul>
				<li><a href="innovation.php">Innovation</a></li>
				<li><a href="testemonials.php">Testemonials</a></li>
				<li><a href="projects.php" class="active">Projects</a></li>
			</ul>
			</li>
			<li><a href="group.php">Group</a></li>
			<li><a href="devices.php">All Devices</a></li>
			<li><a href="sl.php">All SL Services</a></li>
			<li><a href="assist.php">All Assistant Services</a></li>
		</ul>
	</div>
	<div class="maincontent">
		<a href="">
			<div class="homepagepic" style="background-image: url('images/6.jpg');">
				<div class="homepagetitle"> Projects </div>
			</div>
		</a>
		<div class="pagecontent">
			<h3 style="font-weight: 400; margin: 0px 0px 5px; font-size: 14px; padding-bottom: 5px; padding-top: 5px; width: 300px; font-family: arial, sans-serif !important;">
			<span class="blu-tit" style="text-decoration: none; outline: none 0px; color: rgb(0, 70, 145) !important; font-family: &quot;TIM Sans&quot;, sans-serif; font-size: 16px; line-height: 15.6px; font-weight: 900; margin: 0px 0px 10px; text-transform: uppercase; background-color: rgb(255, 255, 255);">PROMOTE THE INTEGRATION OF FOREIGN CITIZENS THROUGH THE USE OF TECHNOLOGY PLATFORMS</span></h3>
		<h5 style="font-size: 11px; margin: 0px; color: rgb(51, 51, 51); font-family: &quot;TIM Sans&quot;, sans-serif; line-height: 15.6px; background-color: rgb(255, 255, 255);">
			Social</h5>
		<div class="date" style="position: absolute; right: 0px; top: 20px; color: rgb(102, 102, 102); font-family: Arial, Helvetica, sans-serif; font-size: 12px; line-height: 15.6px; background-color: rgb(255, 255, 255);">
			&nbsp;</div>
		<p class="rtejustify" style="text-decoration: none; outline: none 0px; color: rgb(102, 102, 102); font-family: Arial, Helvetica, sans-serif; font-size: 12px; line-height: 1.2em; margin: 0px 0px 5px; text-align: justify; height: 47px; overflow: hidden; background-color: rgb(255, 255, 255);">
			<samp><span style="color:#000000;"><span style="font-size:12px;">Dedicated to municipalities with over 50,000 inhabitants (at least 9% of foreigners) with innovative projects to remove the communication barriers that make it difficult to obtain information useful for everyday life</span></span></samp></p>
		<div>
			<h3 style="font-weight: 400; margin: 0px 0px 5px; font-size: 14px; padding-bottom: 5px; padding-top: 5px; width: 300px; font-family: arial, sans-serif !important;">
				<span class="blu-tit" style="text-decoration: none; outline: none 0px; color: rgb(0, 70, 145) !important; font-family: &quot;TIM Sans&quot;, sans-serif; font-size: 16px; line-height: 15.6px; font-weight: 900; margin: 0px 0px 10px; text-transform: uppercase; background-color: rgb(255, 255, 255);">INVISIBLE ASSETS.&nbsp;PLACES AND MASTERY OF CRAFT TRADITIONS</span></h3>
			<h5 style="font-size: 11px; margin: 0px; color: rgb(51, 51, 51); font-family: &quot;TIM Sans&quot;, sans-serif; line-height: 15.6px; background-color: rgb(255, 255, 255);">
				historical and artistic heritage</h5>
			<div class="date" style="position: absolute; right: 0px; top: 20px; color: rgb(102, 102, 102); font-family: Arial, Helvetica, sans-serif; font-size: 12px; line-height: 15.6px; background-color: rgb(255, 255, 255);">
				&nbsp;</div>
			<p class="rtejustify" style="margin: 0px 0px 5px; text-align: justify; line-height: 1.2em; color: rgb(102, 102, 102); height: 47px; overflow: hidden;">
				<samp><span style="color:#000000;"><span style="font-size:12px;">Dedicated to projects that adopt business models geared to the recovery of &quot;invisible places&quot;, the tradition and the preservation of the &quot;mastery&quot; of Italian craftsmanship</span></span></samp></p>
		</div>		</div>
	</div>
	            <div class="footer">
                <div>
                    Telecom Italia 2012 - P.IVA 00488410010
                </div>
            </div>
        </div>
    </body>
</html>